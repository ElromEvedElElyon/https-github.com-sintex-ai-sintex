# STBTCX ChatGPT Plugin - Complete Deployment Guide

## 🚀 Ultra-Deep Integration with OpenAI Agentic Checkout

### Overview
This plugin enables users to purchase STBTCX tokens directly within ChatGPT without leaving the conversation, using OpenAI's Agentic Checkout framework similar to Solana Labs' implementation.

## Architecture Components

### 1. **Plugin Manifest** (`manifest.json`)
- Defines plugin capabilities
- OAuth2 authentication flow
- Agentic Checkout enabled
- Multi-currency support

### 2. **OpenAPI Specification** (`openapi.yaml`)
- Complete API endpoints for token operations
- Price checking
- Wallet management
- Purchase flow
- Transaction history

### 3. **Agentic Checkout Integration** (`agentic_checkout_integration.py`)
- Secure payment processing
- Solana blockchain integration
- Multi-payment method support
- Real-time token delivery

## 🔧 Deployment Steps

### Step 1: Backend Setup on Sintex.AI

```bash
# 1. Deploy API endpoints
cd /var/www/sintex.ai/api
cp stbtcx_chatgpt_plugin/* .

# 2. Install dependencies
pip install -r requirements.txt

# 3. Configure environment variables
export SOLANA_RPC_URL="https://api.mainnet-beta.solana.com"
export STBTCX_MINT_ADDRESS="YourTokenMintAddress"
export OPENAI_API_KEY="your-openai-api-key"
export OPENAI_SECRET_KEY="your-openai-secret-key"
export SINTEX_API_KEY="your-sintex-api-key"

# 4. Start API server
python app.py
```

### Step 2: Configure OAuth2

1. Register your plugin with OpenAI:
   ```
   https://platform.openai.com/plugins/register
   ```

2. Set OAuth endpoints:
   - Authorization URL: `https://sintex.ai/oauth/authorize`
   - Token URL: `https://sintex.ai/oauth/token`
   - Scopes: `wallet:read wallet:write transaction:create`

### Step 3: Deploy Smart Contracts

```javascript
// Deploy on Solana using Anchor
anchor deploy --provider.cluster mainnet
```

### Step 4: Configure Nginx

```nginx
server {
    listen 443 ssl;
    server_name api.sintex.ai;
    
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    location /.well-known/ai-plugin.json {
        alias /var/www/sintex.ai/stbtcx_chatgpt_plugin/manifest.json;
    }
    
    location /.well-known/openapi.yaml {
        alias /var/www/sintex.ai/stbtcx_chatgpt_plugin/openapi.yaml;
    }
    
    location /v1/ {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### Step 5: Submit to OpenAI

1. Go to: https://platform.openai.com/plugins/submit
2. Enter plugin URL: `https://sintex.ai/.well-known/ai-plugin.json`
3. Submit for review

## 💳 Payment Flow

### User Experience in ChatGPT:

1. **User**: "I want to buy 100 STBTCX tokens"

2. **ChatGPT**: 
   ```
   📊 STBTCX is currently trading at $0.125 USD
   
   🛒 Purchase order created!
   💰 Amount: 100 STBTCX
   💵 Total: $12.81 USD (includes 2.5% fee)
   🔗 [Complete Purchase](secure-checkout-link)
   
   ⏱️ This link expires in 10 minutes.
   ```

3. **User clicks link** → Opens Agentic Checkout
   - Secure payment form
   - Multiple payment methods
   - Real-time processing

4. **After payment**:
   ```
   🎉 Purchase successful!
   ✅ 100 STBTCX sent to your wallet
   🔗 [View Transaction](solscan-link)
   ```

## 🔐 Security Features

1. **Request Signing**: All requests validated with HMAC-SHA256
2. **Encryption**: Sensitive data encrypted with Fernet
3. **OAuth2**: Secure authentication flow
4. **Rate Limiting**: Prevent abuse
5. **Wallet Validation**: Verify Solana addresses
6. **SSL/TLS**: All communications encrypted

## 📊 Monitoring & Analytics

```python
# Track plugin usage
analytics = {
    "total_purchases": 0,
    "total_volume_usd": 0,
    "unique_users": set(),
    "popular_payment_methods": {},
    "conversion_rate": 0
}
```

## 🧪 Testing

### Test in ChatGPT:

1. Enable developer mode
2. Install plugin locally:
   ```
   https://chat.openai.com/settings/plugins
   Add: https://sintex.ai/.well-known/ai-plugin.json
   ```

3. Test commands:
   - "What's the current price of STBTCX?"
   - "Connect my wallet: 7EYnhQoR9YM3N7UoaKRoA44Uy8JeaZV3qyouov87awMs"
   - "Buy 50 STBTCX tokens"
   - "Show my transaction history"

## 📈 Expected Results

- **Seamless Integration**: Users never leave ChatGPT
- **High Conversion**: Simplified purchase flow
- **Trust**: OpenAI's Agentic Checkout provides security
- **Speed**: Instant token delivery on Solana
- **Multi-currency**: Support USD, BRL, EUR, crypto

## 🚦 Production Checklist

- [ ] API endpoints deployed and tested
- [ ] OAuth2 configuration complete
- [ ] SSL certificates installed
- [ ] Solana wallet configured
- [ ] Payment processor integrated
- [ ] Rate limiting configured
- [ ] Monitoring setup
- [ ] Error handling tested
- [ ] Plugin submitted to OpenAI
- [ ] Documentation complete

## 🆘 Support

For integration support:
- Email: support@sintex.ai
- Discord: discord.gg/sintexai
- Telegram: @sintexai_support

## 📝 License

MIT License - Open source implementation

---

**Note**: This integration provides the same capabilities as Solana Labs' ChatGPT plugin but specifically for STBTCX tokens on the Sintex.AI platform.